importScripts("tgsolve_adapter.js", "background.js");

const TTG_SOLVE_HOST = "https://api.tgsolve.com";

function normalizeTtgConfig(config) {
    if (!config) return config;

    return {
        ...config,
        clientKey: String(config.clientKey || "").trim(),
        host: TTG_SOLVE_HOST,
        imageclassification: false,
        hcaptcha: false,
        imagetotext: false,
        rainbow: false,
        isTextCaptcha: false,
        isOpenCloudflare: false,
        recaptchaConfig: {
            ...(config.recaptchaConfig || {}),
            isOpen: false,
            isOpenProtocol: false
        },
        hcaptchaConfig: {
            ...(config.hcaptchaConfig || {}),
            isAutoRefresh: false
        },
        awsCaptchaConfig: {
            ...(config.awsCaptchaConfig || {}),
            isOpen: false
        },
        funcaptchaConfig: {
            ...(config.funcaptchaConfig || {}),
            isOpen: (config.funcaptchaConfig && config.funcaptchaConfig.isOpen) !== false
        }
    };
}

chrome.storage.local.get(["config"], ({ config }) => {
    if (!config) return;

    const nextConfig = normalizeTtgConfig(config);
    if (JSON.stringify(config) !== JSON.stringify(nextConfig)) {
        chrome.storage.local.set({ config: nextConfig });
    }
});
