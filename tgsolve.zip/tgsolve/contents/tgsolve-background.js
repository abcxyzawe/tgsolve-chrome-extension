(() => {
  const DEFAULTS = {
    api_key: "",
    api_host: "https://api.tgsolve.com",
    imginstructions: "funcaptcha-img",
    power_on: true,
    funcaptcha: {
      delayClick: 100,
      loop: true,
      loopCount: 1,
      isActive: true,
      maxImageCaptcha: 25
    }
  };
  const POLL_INTERVAL_MS = 1500;
  const FETCH_TIMEOUT_MS = 25000;

  function delay(ms) {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }

  function normalizeHost(host) {
    const raw = String(host || DEFAULTS.api_host).trim();
    const withProtocol = /^https?:\/\//i.test(raw) ? raw : `https://${raw}`;
    return withProtocol.replace(/\/+$/, "");
  }

  function apiBases(host) {
    const base = normalizeHost(host);
    return [base, `${base}/api/v1`, "https://api.tgsolve.com", "https://api.tgsolve.com/api/v1"];
  }

  function parseJson(value, fallback = {}) {
    if (!value) return fallback;
    if (typeof value === "object") return value;
    try {
      return JSON.parse(value);
    } catch (error) {
      return fallback;
    }
  }

  function stripDataUrl(value) {
    const text = String(value || "");
    const comma = text.indexOf(",");
    return text.startsWith("data:") && comma > -1 ? text.slice(comma + 1) : text;
  }

  async function storageGet(keys) {
    return chrome.storage.local.get(keys);
  }

  async function storageSet(values) {
    return chrome.storage.local.set(values);
  }

  async function readBundledConfig() {
    try {
      const response = await fetch(chrome.runtime.getURL("configs.json"), { cache: "no-store" });
      if (!response.ok) return {};
      const data = await response.json();
      return data && typeof data === "object" ? data : {};
    } catch (error) {
      console.warn("[tgsolve] cannot read configs.json", error);
      return {};
    }
  }

  async function initStorage() {
    const bundled = await readBundledConfig();
    const current = await storageGet(null);
    const bundledSignature = JSON.stringify({
      api_key: bundled.api_key,
      api_host: bundled.api_host,
      imginstructions: bundled.imginstructions,
      funcaptcha: bundled.funcaptcha
    });
    const applyBundled = current.tgsolve_config_signature !== bundledSignature;
    const next = {
      ...DEFAULTS,
      ...current,
      ...(applyBundled ? bundled : {}),
      api_key: applyBundled && bundled.api_key !== undefined ? bundled.api_key : current.api_key || DEFAULTS.api_key,
      api_host: applyBundled && bundled.api_host !== undefined ? bundled.api_host : current.api_host || DEFAULTS.api_host,
      imginstructions:
        applyBundled && bundled.imginstructions !== undefined
          ? bundled.imginstructions
          : current.imginstructions || DEFAULTS.imginstructions,
      funcaptcha: {
        ...DEFAULTS.funcaptcha,
        ...(current.funcaptcha || {}),
        ...(applyBundled ? bundled.funcaptcha || {} : {})
      },
      tgsolve_config_signature: bundledSignature,
      initialized: true
    };
    await storageSet(next);
  }

  async function getApiConfig(rawClientKey = "") {
    const config = await storageGet(["api_key", "api_host", "imginstructions"]);
    return {
      key: String(rawClientKey || config.api_key || "").trim(),
      host: normalizeHost(config.api_host),
      imginstructions: String(config.imginstructions || DEFAULTS.imginstructions).trim()
    };
  }

  async function fetchText(url, options = {}, timeoutMs = FETCH_TIMEOUT_MS) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), timeoutMs);
    try {
      const response = await fetch(url, {
        ...options,
        cache: "no-store",
        signal: controller.signal
      });
      const text = (await response.text()).trim();
      if (!response.ok) throw new Error(text || `HTTP ${response.status}`);
      if (/^\s*<!doctype html/i.test(text) || /^\s*<html/i.test(text)) {
        throw new Error("HTML response from tgsolve API");
      }
      return text;
    } finally {
      clearTimeout(timer);
    }
  }

  async function fetchApiText(config, path, options, timeoutMs) {
    const errors = [];
    for (const base of apiBases(config.host)) {
      const url = `${base}/${path.replace(/^\/+/, "")}`;
      try {
        return await fetchText(url, options, timeoutMs);
      } catch (error) {
        errors.push(`${base}: ${error && error.message ? error.message : String(error)}`);
      }
    }
    throw new Error(errors.join(" | "));
  }

  async function urlToBase64(url) {
    if (!url) return "";
    if (String(url).startsWith("data:image/")) return stripDataUrl(url);
    const response = await fetch(url, { cache: "no-store" });
    if (!response.ok) throw new Error(`image fetch HTTP ${response.status}`);
    const blob = await response.blob();
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onloadend = () => resolve(stripDataUrl(reader.result));
      reader.onerror = reject;
      reader.readAsDataURL(blob);
    });
  }

  async function extractBase64Image(task) {
    const image =
      task.imageBase64 ||
      task.body ||
      task.image ||
      task.img ||
      task.queries ||
      (Array.isArray(task.imageBase64s) ? task.imageBase64s[0] : "") ||
      "";
    if (image) return stripDataUrl(Array.isArray(image) ? image[0] : image);

    const imageUrl =
      task.imageUrl ||
      task.image_url ||
      (Array.isArray(task.imageUrls) ? task.imageUrls[0] : "") ||
      "";
    return imageUrl ? urlToBase64(imageUrl) : "";
  }

  function getInstruction(task, config) {
    return (
      task.imginstructions ||
      task.other ||
      task.question ||
      task.prompt ||
      task.comment ||
      config.imginstructions ||
      "funcaptcha-img"
    );
  }

  function compactSubmitLog(payload) {
    return {
      ...payload,
      body: payload.body
        ? {
            base64Length: payload.body.length,
            base64Start: payload.body.slice(0, 60),
            base64End: payload.body.slice(-30)
          }
        : ""
    };
  }

  function parseAnswerList(answer) {
    let text = String(answer || "").replace(/^OK\|/, "").trim();
    if (!text) return [];
    try {
      const parsed = JSON.parse(text);
      if (Array.isArray(parsed)) return parsed;
      if (parsed && Array.isArray(parsed.objects)) return parsed.objects;
      if (parsed && parsed.solution && Array.isArray(parsed.solution.objects)) return parsed.solution.objects;
      if (parsed && typeof parsed.answer === "string") return parseAnswerList(parsed.answer);
    } catch (error) {
      // Plain text is the normal tgsolve result format.
    }
    const numbers = text.match(/\d+/g);
    return numbers && numbers.length ? numbers.map(Number).filter(Number.isFinite) : [text];
  }

  function parseSolution(answer) {
    const text = String(answer || "").replace(/^OK\|/, "").trim();
    const values = parseAnswerList(text);
    const boolIndex = values.findIndex((item) => item === true || String(item).toLowerCase() === "true");
    const numbers = values.map(Number).filter(Number.isFinite);
    let index = text;
    if (boolIndex >= 0) {
      index = boolIndex + 1;
    } else if (
      numbers.length > 1 &&
      numbers.every((item) => item === 0 || item === 1)
    ) {
      const maskIndex = numbers.findIndex((item) => item === 1);
      index = maskIndex >= 0 ? maskIndex + 1 : text;
    } else if (numbers.length) {
      index = numbers.includes(0) ? numbers[0] + 1 : numbers[0];
    }
    return {
      index: String(index),
      text,
      objects: numbers
    };
  }

  function errorResult(code, description, extra = {}) {
    return {
      error: true,
      errorCode: code || "TGSOLVE_ERROR",
      errorDescription: description || code || "tgsolve error",
      ...extra
    };
  }

  async function createTask(rawData) {
    const data = parseJson(rawData);
    const task = data.task && typeof data.task === "object" ? data.task : data;
    const config = await getApiConfig(data.clientKey);
    const body = await extractBase64Image(task);
    const imginstructions = String(getInstruction(task, config) || "funcaptcha-img");

    if (!config.key) return errorResult("ERROR_KEY_DOES_NOT_EXIST", "Missing tgsolve API key");
    if (!body) return errorResult("ERROR_REQUIRED_FIELDS", "Missing base64 image body");

    const form = new URLSearchParams();
    form.set("type-captcha", "funcaptcha-img");
    form.set("method", "base64");
    form.set("body", body);
    form.set("imginstructions", imginstructions);
    form.set("requestId", data.requestId || `${Date.now()}-${Math.random().toString(36).slice(2)}`);

    try {
      console.warn("[tgsolve] in.php payload", compactSubmitLog({
        typeCaptcha: "funcaptcha-img",
        method: "base64",
        imginstructions,
        body
      }));
      const submitText = await fetchApiText(config, `in.php?key=${encodeURIComponent(config.key)}`, {
        method: "POST",
        body: form
      });
      console.warn("[tgsolve] in.php response", submitText);

      if (submitText.startsWith("OK|")) {
        return { taskId: submitText.split("|")[1] };
      }
      if (submitText.includes("CAPTCHA_UNSOLV") || submitText.includes("UNSOLVABLE")) {
        return errorResult(submitText, `Job failed: ${submitText}`);
      }
      return errorResult(submitText || "TGSOLVE_SUBMIT_ERROR", submitText || "tgsolve submit error");
    } catch (error) {
      return errorResult(
        error && error.name === "AbortError" ? "TGSOLVE_TIMEOUT" : "TGSOLVE_NETWORK",
        error && error.message ? error.message : String(error)
      );
    }
  }

  async function getTaskResult(rawData, timeWait = 30) {
    const data = parseJson(rawData);
    const taskId = String(data.taskId || data.id || "").trim();
    if (!taskId) return { status: "fail", errorDescription: "Missing taskId" };

    const config = await getApiConfig(data.clientKey);
    const attempts = Math.max(1, Number(timeWait) || 30);
    await delay(POLL_INTERVAL_MS);

    for (let attempt = 0; attempt < attempts; attempt += 1) {
      try {
        const resultText = await fetchApiText(
          config,
          `res.php?key=${encodeURIComponent(config.key)}&action=get&id=${encodeURIComponent(taskId)}`,
          { method: "GET" },
          10000
        );
        console.warn("[tgsolve] res.php response", { taskId, attempt, resultText });

        if (resultText === "CAPCHA_NOT_READY" || resultText === "CAPTCHA_NOT_READY" || !resultText) {
          await delay(POLL_INTERVAL_MS);
          continue;
        }
        if (resultText.startsWith("OK|")) {
          return {
            status: "ready",
            solution: parseSolution(resultText.slice(3))
          };
        }
        if (resultText.startsWith("ERROR_")) {
          const retryable = resultText.includes("CAPTCHA_UNSOLV") || resultText.includes("UNSOLVABLE");
          return {
            status: "fail",
            errorDescription: retryable ? `Job failed: ${resultText}` : resultText
          };
        }
        return {
          status: "ready",
          solution: parseSolution(resultText)
        };
      } catch (error) {
        await delay(POLL_INTERVAL_MS);
      }
    }

    return { status: "fail", errorDescription: "TGSOLVE_RESULT_TIMEOUT" };
  }

  async function getUrl(sender) {
    if (sender && sender.tab && sender.tab.id) {
      try {
        const tab = await chrome.tabs.get(sender.tab.id);
        return tab.url || sender.url || "";
      } catch (error) {
        return sender.url || "";
      }
    }
    return sender && sender.url ? sender.url : "";
  }

  function handleMessage(message, sender, sendResponse) {
    const type = message && message.type;

    if (type === "createTask") {
      createTask(message.data).then(sendResponse);
      return true;
    }
    if (type === "getTaskResult" || type === "getTaskResultWithFuncaptcha") {
      const payload = message.data && message.data.data !== undefined ? message.data.data : message.data;
      const wait = message.data && message.data.timeWait !== undefined ? message.data.timeWait : 30;
      getTaskResult(payload, wait).then(sendResponse);
      return true;
    }
    if (type === "getURL") {
      getUrl(sender).then(sendResponse);
      return true;
    }
    if (type === "createImageBase64") {
      urlToBase64(message.data && message.data.url)
        .then((base64) => sendResponse(base64))
        .catch(() => sendResponse(""));
      return true;
    }

    if (
      [
        "reportTask",
        "sendCaptchaReport2",
        "uploadFuncaptchaWrongImages",
        "hcaptchaDataUsed",
        "imageToTextDataUsed",
        "getMotionQuestions",
        "getImageToTextConfigs",
        "frameReport",
        "logCaptchaToLocal"
      ].includes(type)
    ) {
      sendResponse({ received: true });
      return true;
    }

    sendResponse("");
    return true;
  }

  chrome.runtime.onInstalled.addListener(() => {
    initStorage().catch((error) => console.warn("[tgsolve] init failed", error));
  });
  chrome.runtime.onStartup.addListener(() => {
    initStorage().catch((error) => console.warn("[tgsolve] init failed", error));
  });
  chrome.runtime.onMessage.addListener(handleMessage);

  initStorage().catch((error) => console.warn("[tgsolve] init failed", error));
})();
